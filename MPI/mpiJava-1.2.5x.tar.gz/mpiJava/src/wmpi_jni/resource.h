//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by vwmpi.rc
//
#define Icon1                           101
#define options                         109
#define ID_prcgfile                     1001
#define ID_gmsize                       1002
#define ID_dbg                          1003
#define ID_rdbg                         1004
#define ID_outfile                      1005
#define ID_routfile                     1006
#define ID_default                      1012
#define ID_default2                     1013
#define ID_noshared                     1015
#define ID_onlylocal                    1017
#define ID_norstart                     1018

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
